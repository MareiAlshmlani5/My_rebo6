# How to run LLM

## LMStudio.ai: Local AI, on Your Computer

- https://lmstudio.ai/
- Integration with [Unsloth](https://unsloth.ai/docs/basics/inference-and-deployment/lm-studio)
